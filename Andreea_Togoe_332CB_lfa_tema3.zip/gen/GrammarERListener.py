# Generated from /home/andreea/PycharmProjects/tema3LFA/GrammarER.g4 by ANTLR 4.9
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .GrammarERParser import GrammarERParser
else:
    from GrammarERParser import GrammarERParser

# This class defines a complete listener for a parse tree produced by GrammarERParser.
class GrammarERListener(ParseTreeListener):

    # Enter a parse tree produced by GrammarERParser#orr.
    def enterOrr(self, ctx:GrammarERParser.OrrContext):
        pass

    # Exit a parse tree produced by GrammarERParser#orr.
    def exitOrr(self, ctx:GrammarERParser.OrrContext):
        pass


    # Enter a parse tree produced by GrammarERParser#concat.
    def enterConcat(self, ctx:GrammarERParser.ConcatContext):
        pass

    # Exit a parse tree produced by GrammarERParser#concat.
    def exitConcat(self, ctx:GrammarERParser.ConcatContext):
        pass


    # Enter a parse tree produced by GrammarERParser#kleene.
    def enterKleene(self, ctx:GrammarERParser.KleeneContext):
        pass

    # Exit a parse tree produced by GrammarERParser#kleene.
    def exitKleene(self, ctx:GrammarERParser.KleeneContext):
        pass


    # Enter a parse tree produced by GrammarERParser#gramm.
    def enterGramm(self, ctx:GrammarERParser.GrammContext):
        pass

    # Exit a parse tree produced by GrammarERParser#gramm.
    def exitGramm(self, ctx:GrammarERParser.GrammContext):
        pass



del GrammarERParser